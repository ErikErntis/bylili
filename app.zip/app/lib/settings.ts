/** Public website settings. Restart dev or rebuild/redeploy after changing. */
export const siteSettings = {
  testimonials: {
    enabled: false,
    preview: false,
  },
  portfolio: {
    enabled: false,
    homepageLimit: 3,
  },
};
